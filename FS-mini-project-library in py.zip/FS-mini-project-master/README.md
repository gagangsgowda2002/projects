# Library Management System

To execute, clone the repository, inside the LibraryManagementSystem-master directory run the GUI.py file

$ python3 GUI.py

Admin:  id: admin
        password: admin
